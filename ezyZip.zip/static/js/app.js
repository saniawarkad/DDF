/**
 * FKNews - AI Fake News Verification Dashboard
 * Frontend Controller & API Integration
 */

(function () {
    'use strict';

    // Ephemeral session identifier generated in memory per page load
    // NEVER stored in localStorage or persistent cookies
    const sessionId = 'fk_sess_' + Math.random().toString(36).substring(2, 12) + '_' + Date.now();

    // In-memory state for the active tab/session
    let stagedFiles = [];
    let processedDocs = [];
    let lastRetrievedChunks = [];
    let currentResult = null;

    // DOM Elements
    const elements = {
        // Upload elements
        dropZone: document.getElementById('drop-zone'),
        fileInput: document.getElementById('file-input'),
        fileListContainer: document.getElementById('file-list-container'),
        btnProcessDocs: document.getElementById('btn-process-docs'),

        // Claim elements
        claimInput: document.getElementById('claim-input'),
        btnVerifyClaim: document.getElementById('btn-verify-claim'),

        // Results elements
        resultsSection: document.getElementById('results-section'),
        resultDocCount: document.getElementById('result-document-count'),
        resultConfidenceCircle: document.getElementById('result-confidence-circle'),
        resultConfidenceText: document.getElementById('result-confidence-text'),
        resultVerdictBadge: document.getElementById('result-verdict-badge'),
        resultVerdictIcon: document.getElementById('result-verdict-icon'),
        resultVerdictText: document.getElementById('result-verdict-text'),
        resultExplanation: document.getElementById('result-explanation'),
        resultSourceCitation: document.getElementById('result-source-citation'),
        resultEvidenceQuote: document.getElementById('result-evidence-quote'),
        btnViewEvidence: document.getElementById('btn-view-evidence'),

        // Stat counters
        statDocuments: document.getElementById('stat-documents'),
        statClaims: document.getElementById('stat-claims'),
        statFake: document.getElementById('stat-fake'),
        statConfidence: document.getElementById('stat-confidence'),

        // Navigation links
        navDashboard: document.querySelectorAll('[data-nav="dashboard"]'),
        navVerify: document.querySelectorAll('[data-nav="verify"]'),
        navUpload: document.querySelectorAll('[data-nav="upload"]'),
        navStats: document.querySelectorAll('[data-nav="stats"]'),
        navHistory: document.querySelectorAll('[data-nav="history"]'),
        navHelp: document.querySelectorAll('[data-nav="help"]'),
        navSignOut: document.querySelectorAll('[data-nav="signout"]'),
        btnGetStarted: document.getElementById('btn-get-started'),

        // Modals
        evidenceModal: document.getElementById('evidence-modal'),
        evidenceModalClose: document.getElementById('evidence-modal-close'),
        evidenceModalContent: document.getElementById('evidence-modal-content'),

        historyModal: document.getElementById('history-modal'),
        historyModalClose: document.getElementById('history-modal-close'),
        historyModalContent: document.getElementById('history-modal-content'),

        helpModal: document.getElementById('help-modal'),
        helpModalClose: document.getElementById('help-modal-close'),

        // Toast Container
        toastContainer: document.getElementById('toast-container')
    };

    // Format file sizes
    function formatBytes(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    // Toast notification helper
    function showToast(message, type = 'info', duration = 4000) {
        if (!elements.toastContainer) return;

        const toast = document.createElement('div');
        toast.className = `flex items-center gap-3 p-4 rounded-xl shadow-lg border text-sm transition-all duration-300 transform translate-y-2 opacity-0 glass-panel pointer-events-auto max-w-md w-full`;

        let icon = 'info';
        let iconColor = 'text-primary';

        if (type === 'success') {
            icon = 'check_circle';
            iconColor = 'text-green-600';
        } else if (type === 'error') {
            icon = 'error';
            iconColor = 'text-red-600';
        } else if (type === 'warning') {
            icon = 'warning';
            iconColor = 'text-amber-500';
        }

        toast.innerHTML = `
            <span class="material-symbols-outlined ${iconColor}" data-icon="${icon}">${icon}</span>
            <span class="flex-1 text-on-background font-medium">${message}</span>
            <button class="text-outline hover:text-primary transition-colors toast-close-btn">
                <span class="material-symbols-outlined text-[18px]" data-icon="close">close</span>
            </button>
        `;

        elements.toastContainer.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.remove('translate-y-2', 'opacity-0');
        });

        const closeBtn = toast.querySelector('.toast-close-btn');
        const removeToast = () => {
            toast.classList.add('opacity-0', 'translate-y-2');
            setTimeout(() => toast.remove(), 300);
        };

        if (closeBtn) closeBtn.addEventListener('click', removeToast);
        setTimeout(removeToast, duration);
    }

    // Initialize session with backend
    async function initSession() {
        try {
            const resp = await fetch('/api/session/init', {
                method: 'POST',
                headers: { 'X-Session-ID': sessionId }
            });
            if (resp.ok) {
                const data = await resp.json();
                updateStatsDisplay(data.stats);
                if (data.documents && data.documents.length > 0) {
                    processedDocs = data.documents;
                    renderFileList();
                }
            }
        } catch (err) {
            console.warn('Session init error:', err);
        }
    }

    // Update real-time statistics UI
    function updateStatsDisplay(stats) {
        if (!stats) return;
        if (elements.statDocuments) elements.statDocuments.textContent = stats.documents_uploaded || 0;
        if (elements.statClaims) elements.statClaims.textContent = stats.claims_verified || 0;
        if (elements.statFake) elements.statFake.textContent = stats.fake_claims_detected || 0;
        if (elements.statConfidence) elements.statConfidence.textContent = (stats.average_confidence || 0) + '%';
    }

    // Refresh stats from backend
    async function refreshStats() {
        try {
            const resp = await fetch('/api/stats', {
                headers: { 'X-Session-ID': sessionId }
            });
            if (resp.ok) {
                const stats = await resp.json();
                updateStatsDisplay(stats);
            }
        } catch (err) {
            console.error('Failed to refresh stats:', err);
        }
    }

    // Render list of files (both staged and processed)
    function renderFileList() {
        if (!elements.fileListContainer) return;
        elements.fileListContainer.innerHTML = '';

        const hasFiles = stagedFiles.length > 0 || processedDocs.length > 0;
        if (!hasFiles) {
            elements.fileListContainer.innerHTML = `
                <div class="text-center py-4 text-outline font-label-sm">
                    No reference documents added yet. Drag & drop or browse PDF / CSV files above.
                </div>
            `;
            return;
        }

        // Render processed documents
        processedDocs.forEach((doc, idx) => {
            const item = document.createElement('div');
            item.className = 'flex items-center justify-between p-3 bg-surface-container-lowest rounded-lg border border-outline-variant/30 transition-all';
            const icon = doc.doc_type === 'csv' ? 'table_chart' : 'picture_as_pdf';
            const sizeLabel = doc.file_size ? ` • ${formatBytes(doc.file_size)}` : '';
            const chunksLabel = doc.total_chunks || doc.chunk_count ? ` (${doc.total_chunks || doc.chunk_count} chunks)` : '';

            item.innerHTML = `
                <div class="flex items-center gap-2 overflow-hidden">
                    <span class="material-symbols-outlined text-primary flex-shrink-0" data-icon="${icon}">${icon}</span>
                    <span class="font-label-md text-on-background truncate" title="${doc.doc_name}">${doc.doc_name}</span>
                    <span class="text-xs text-outline flex-shrink-0">${sizeLabel}${chunksLabel}</span>
                </div>
                <div class="flex items-center gap-3 flex-shrink-0">
                    <span class="font-label-sm text-primary flex items-center gap-1">
                        <span class="material-symbols-outlined text-[16px]" data-icon="check_circle">check_circle</span> Processed
                    </span>
                    <button class="text-outline hover:text-red-500 transition-colors btn-remove-doc" data-doc="${doc.doc_name}" title="Remove document">
                        <span class="material-symbols-outlined text-[18px]" data-icon="close">close</span>
                    </button>
                </div>
            `;
            elements.fileListContainer.appendChild(item);
        });

        // Render staged (unprocessed) files
        stagedFiles.forEach((file, idx) => {
            const item = document.createElement('div');
            item.className = 'flex items-center justify-between p-3 bg-surface-container-low/70 rounded-lg border border-dashed border-outline-variant/50 transition-all';
            const isCsv = file.name.toLowerCase().endsWith('.csv');
            const icon = isCsv ? 'table_chart' : 'picture_as_pdf';

            item.innerHTML = `
                <div class="flex items-center gap-2 overflow-hidden">
                    <span class="material-symbols-outlined text-outline flex-shrink-0" data-icon="${icon}">${icon}</span>
                    <span class="font-label-md text-on-background truncate" title="${file.name}">${file.name}</span>
                    <span class="text-xs text-outline flex-shrink-0">• ${formatBytes(file.size)}</span>
                </div>
                <div class="flex items-center gap-3 flex-shrink-0">
                    <span class="font-label-sm text-outline flex items-center gap-1">
                        <span class="material-symbols-outlined text-[16px]" data-icon="hourglass_empty">hourglass_empty</span> Ready to process
                    </span>
                    <button class="text-outline hover:text-red-500 transition-colors btn-remove-staged" data-index="${idx}" title="Remove file">
                        <span class="material-symbols-outlined text-[18px]" data-icon="close">close</span>
                    </button>
                </div>
            `;
            elements.fileListContainer.appendChild(item);
        });

        // Attach removal listeners
        elements.fileListContainer.querySelectorAll('.btn-remove-doc').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const docName = e.currentTarget.dataset.doc;
                await deleteDocument(docName);
            });
        });

        elements.fileListContainer.querySelectorAll('.btn-remove-staged').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.index, 10);
                stagedFiles.splice(idx, 1);
                renderFileList();
            });
        });
    }

    // Delete a document from server session
    async function deleteDocument(docName) {
        try {
            const resp = await fetch(`/api/documents/${encodeURIComponent(docName)}`, {
                method: 'DELETE',
                headers: { 'X-Session-ID': sessionId }
            });
            if (resp.ok) {
                processedDocs = processedDocs.filter(d => d.doc_name !== docName);
                renderFileList();
                refreshStats();
                showToast(`Removed '${docName}' from session memory.`, 'info');
            } else {
                showToast(`Failed to remove '${docName}'.`, 'error');
            }
        } catch (err) {
            showToast(`Error removing document: ${err.message}`, 'error');
        }
    }

    // Add files to stage
    function stageFiles(files) {
        let addedCount = 0;
        for (const file of files) {
            const name = file.name.toLowerCase();
            if (!name.endsWith('.pdf') && !name.endsWith('.csv')) {
                showToast(`Skipped '${file.name}': only PDF and CSV files are supported.`, 'warning');
                continue;
            }
            if (file.size > 15 * 1024 * 1024) {
                showToast(`Skipped '${file.name}': file exceeds maximum 15MB limit.`, 'error');
                continue;
            }

            // Check if already staged or processed
            const alreadyStaged = stagedFiles.some(f => f.name === file.name);
            const alreadyProcessed = processedDocs.some(d => d.doc_name === file.name);
            if (alreadyStaged || alreadyProcessed) {
                showToast(`'${file.name}' is already uploaded or staged.`, 'info');
                continue;
            }

            stagedFiles.push(file);
            addedCount++;
        }

        if (addedCount > 0) {
            renderFileList();
            showToast(`${addedCount} document(s) staged. Click 'Process Documents' to index them into FAISS.`, 'info');
        }
    }

    // Upload & Process staged files
    async function processStagedDocuments() {
        if (stagedFiles.length === 0) {
            if (processedDocs.length > 0) {
                showToast('All selected documents have already been processed into FAISS.', 'info');
            } else {
                showToast('Please select or drag & drop PDF/CSV reference files first.', 'warning');
                if (elements.fileInput) elements.fileInput.click();
            }
            return;
        }

        // Set loading state on button
        const originalBtnHtml = elements.btnProcessDocs.innerHTML;
        elements.btnProcessDocs.disabled = true;
        elements.btnProcessDocs.innerHTML = `
            <span class="inline-block animate-spin material-symbols-outlined text-[20px]" data-icon="sync">sync</span>
            Extracting text & Indexing in FAISS...
        `;

        try {
            const formData = new FormData();
            for (const file of stagedFiles) {
                formData.append('files', file);
            }

            const resp = await fetch('/api/documents/upload', {
                method: 'POST',
                headers: {
                    'X-Session-ID': sessionId
                },
                body: formData
            });

            const data = await resp.json();

            if (resp.ok && data.success) {
                // Merge processed docs
                for (const doc of data.documents) {
                    processedDocs = processedDocs.filter(d => d.doc_name !== doc.doc_name);
                    processedDocs.push(doc);
                }
                stagedFiles = [];
                renderFileList();
                refreshStats();
                showToast(data.message, 'success');
            } else {
                const errMsg = data.detail || data.message || 'Failed to process documents.';
                showToast(errMsg, 'error');
            }
        } catch (err) {
            showToast(`Connection error processing documents: ${err.message}`, 'error');
        } finally {
            elements.btnProcessDocs.disabled = false;
            elements.btnProcessDocs.innerHTML = originalBtnHtml;
        }
    }

    // Verify a claim
    async function verifyClaim() {
        const claim = elements.claimInput ? elements.claimInput.value.trim() : '';
        if (!claim) {
            showToast('Please enter a news claim or question to verify.', 'warning');
            if (elements.claimInput) elements.claimInput.focus();
            return;
        }

        if (processedDocs.length === 0) {
            showToast('Please upload and process at least one reference document before verifying a claim.', 'warning');
            if (elements.dropZone) elements.dropZone.scrollIntoView({ behavior: 'smooth' });
            return;
        }

        // Set button loading state
        const originalBtnHtml = elements.btnVerifyClaim.innerHTML;
        elements.btnVerifyClaim.disabled = true;
        elements.btnVerifyClaim.innerHTML = `
            <span class="inline-block animate-spin material-symbols-outlined text-[20px]" data-icon="progress_activity">progress_activity</span>
            Verifying against Reference Documents...
        `;

        try {
            const resp = await fetch('/api/verify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Session-ID': sessionId
                },
                body: JSON.stringify({ claim: claim })
            });

            const data = await resp.json();

            if (resp.ok) {
                currentResult = data;
                lastRetrievedChunks = data.retrieved_chunks || [];
                displayVerificationResult(data);
                refreshStats();

                if (data.error && data.message) {
                    showToast(data.message, 'warning', 6000);
                } else {
                    showToast(`Claim verification complete: Verdict is ${data.verdict}.`, 'success');
                }
            } else {
                const errMsg = data.detail || data.message || 'Error occurred during verification.';
                showToast(errMsg, 'error');
            }
        } catch (err) {
            showToast(`Verification request failed: ${err.message}`, 'error');
        } finally {
            elements.btnVerifyClaim.disabled = false;
            elements.btnVerifyClaim.innerHTML = originalBtnHtml;
        }
    }

    // Update Result Card UI
    function displayVerificationResult(res) {
        if (!elements.resultsSection) return;

        // Smooth scroll to result
        elements.resultsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

        // Update document count
        const docCount = res.total_documents_analyzed || processedDocs.length;
        if (elements.resultDocCount) {
            elements.resultDocCount.textContent = `Analyzed against ${docCount} reference document${docCount === 1 ? '' : 's'}`;
        }

        // Confidence score
        const confidence = typeof res.confidence === 'number' ? res.confidence : 0;
        if (elements.resultConfidenceText) {
            elements.resultConfidenceText.textContent = `${confidence}%`;
        }

        // Format Verdict
        const verdict = (res.verdict || 'NOT ENOUGH EVIDENCE').toUpperCase();
        if (elements.resultVerdictBadge && elements.resultVerdictText && elements.resultVerdictIcon) {
            elements.resultVerdictBadge.className = 'px-4 py-2 rounded-full font-label-md flex items-center gap-2 shadow-sm border transition-all';

            if (verdict === 'TRUE') {
                elements.resultVerdictBadge.classList.add('bg-green-700', 'text-white', 'border-green-800');
                elements.resultVerdictIcon.setAttribute('data-icon', 'verified');
                elements.resultVerdictIcon.textContent = 'verified';
                elements.resultVerdictText.textContent = 'TRUE / VERIFIED';
            } else if (verdict === 'FALSE') {
                elements.resultVerdictBadge.classList.add('bg-primary', 'text-on-primary', 'border-primary');
                elements.resultVerdictIcon.setAttribute('data-icon', 'cancel');
                elements.resultVerdictIcon.textContent = 'cancel';
                elements.resultVerdictText.textContent = 'FAKE NEWS';
            } else {
                elements.resultVerdictBadge.classList.add('bg-amber-600', 'text-white', 'border-amber-700');
                elements.resultVerdictIcon.setAttribute('data-icon', 'help');
                elements.resultVerdictIcon.textContent = 'help';
                elements.resultVerdictText.textContent = 'NOT ENOUGH EVIDENCE';
            }
        }

        // AI Explanation
        if (elements.resultExplanation) {
            elements.resultExplanation.textContent = res.explanation || 'No detailed analysis provided.';
        }

        // Source Citation
        let citation = 'No direct document citation available';
        if (res.source_document) {
            citation = res.source_document;
            if (res.page_number) citation += ` (Page ${res.page_number})`;
            else if (res.row_number) citation += ` (Row ${res.row_number})`;
        } else if (res.retrieved_chunks && res.retrieved_chunks.length > 0) {
            const top = res.retrieved_chunks[0];
            citation = top.doc_name;
            if (top.page_number) citation += ` (Page ${top.page_number})`;
            else if (top.row_number) citation += ` (Row ${top.row_number})`;
        }
        if (elements.resultSourceCitation) {
            elements.resultSourceCitation.textContent = citation;
        }

        // Supporting Evidence Quote
        if (elements.resultEvidenceQuote) {
            const quote = res.supporting_evidence || 'No direct evidence excerpt available.';
            elements.resultEvidenceQuote.textContent = `"${quote}"`;
        }
    }

    // Open Evidence Context Modal
    function openEvidenceModal() {
        if (!elements.evidenceModal || !elements.evidenceModalContent) return;

        if (!lastRetrievedChunks || lastRetrievedChunks.length === 0) {
            elements.evidenceModalContent.innerHTML = `
                <div class="p-8 text-center text-on-surface-variant font-body-md">
                    <span class="material-symbols-outlined text-[48px] text-outline mb-2" data-icon="search_off">search_off</span>
                    <p>No retrieved context chunks are available for the current query.</p>
                </div>
            `;
        } else {
            elements.evidenceModalContent.innerHTML = lastRetrievedChunks.map((chunk, i) => {
                const docName = chunk.doc_name || 'Document';
                let loc = '';
                if (chunk.doc_type === 'pdf' && chunk.page_number) loc = ` • Page ${chunk.page_number}`;
                else if (chunk.doc_type === 'csv' && chunk.row_number) loc = ` • Row ${chunk.row_number}`;
                const score = chunk.similarity_score ? `Relevance: ${Math.round(chunk.similarity_score * 100)}%` : '';

                return `
                    <div class="bg-surface-container-low p-4 rounded-xl border border-outline-variant/30 flex flex-col gap-2">
                        <div class="flex justify-between items-center text-xs font-semibold">
                            <span class="font-label-md text-primary flex items-center gap-1">
                                <span class="material-symbols-outlined text-[16px]" data-icon="description">description</span>
                                ${docName}${loc}
                            </span>
                            <span class="bg-surface-container-highest px-2 py-0.5 rounded text-on-surface-variant">${score}</span>
                        </div>
                        <p class="font-body-md text-on-surface-variant text-sm whitespace-pre-wrap leading-relaxed">${chunk.text}</p>
                    </div>
                `;
            }).join('');
        }

        elements.evidenceModal.classList.remove('hidden');
        elements.evidenceModal.classList.add('flex');
    }

    // Open History Modal
    async function openHistoryModal() {
        if (!elements.historyModal || !elements.historyModalContent) return;

        elements.historyModalContent.innerHTML = `
            <div class="p-8 text-center text-outline">
                <span class="inline-block animate-spin material-symbols-outlined text-[32px]" data-icon="sync">sync</span>
                <p class="mt-2">Loading session verification history...</p>
            </div>
        `;

        elements.historyModal.classList.remove('hidden');
        elements.historyModal.classList.add('flex');

        try {
            const resp = await fetch('/api/history', {
                headers: { 'X-Session-ID': sessionId }
            });
            if (resp.ok) {
                const data = await resp.json();
                const history = data.history || [];

                if (history.length === 0) {
                    elements.historyModalContent.innerHTML = `
                        <div class="p-8 text-center text-on-surface-variant font-body-md">
                            <span class="material-symbols-outlined text-[48px] text-outline mb-2" data-icon="history_toggle_off">history_toggle_off</span>
                            <p>No claims have been verified in this temporary session yet.</p>
                            <p class="text-xs text-outline mt-1">Verification history is stored strictly in memory for this tab.</p>
                        </div>
                    `;
                    return;
                }

                // Render history items in reverse chronological order
                elements.historyModalContent.innerHTML = history.slice().reverse().map((item, idx) => {
                    const verdict = (item.verdict || 'NOT ENOUGH EVIDENCE').toUpperCase();
                    let badgeClass = 'bg-amber-600 text-white';
                    let icon = 'help';
                    let label = 'NOT ENOUGH EVIDENCE';

                    if (verdict === 'TRUE') {
                        badgeClass = 'bg-green-700 text-white';
                        icon = 'verified';
                        label = 'TRUE';
                    } else if (verdict === 'FALSE') {
                        badgeClass = 'bg-primary text-on-primary';
                        icon = 'cancel';
                        label = 'FAKE NEWS';
                    }

                    const timeStr = new Date(item.timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

                    return `
                        <div class="bg-surface-container-low p-4 rounded-xl border border-outline-variant/30 flex flex-col gap-3">
                            <div class="flex justify-between items-center">
                                <span class="text-xs text-outline font-label-sm">${timeStr}</span>
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-bold text-outline">${item.confidence}%</span>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1 ${badgeClass}">
                                        <span class="material-symbols-outlined text-[14px]" data-icon="${icon}">${icon}</span>
                                        ${label}
                                    </span>
                                </div>
                            </div>
                            <p class="font-label-md text-on-background">"${item.claim}"</p>
                            <p class="font-body-md text-sm text-on-surface-variant line-clamp-2">${item.explanation}</p>
                            <div class="flex justify-between items-center pt-2 border-t border-outline-variant/20">
                                <span class="text-xs text-outline truncate max-w-[240px]">${item.source_document || 'Reference context'}</span>
                                <button class="btn-inspect-history text-xs text-primary font-bold hover:underline flex items-center gap-1" data-claim="${encodeURIComponent(item.claim)}" data-verdict="${verdict}" data-conf="${item.confidence}" data-exp="${encodeURIComponent(item.explanation)}" data-src="${encodeURIComponent(item.source_document || '')}" data-page="${item.page_number || ''}" data-row="${item.row_number || ''}" data-evidence="${encodeURIComponent(item.supporting_evidence || '')}">
                                    Inspect in Result
                                    <span class="material-symbols-outlined text-[14px]" data-icon="arrow_forward">arrow_forward</span>
                                </button>
                            </div>
                        </div>
                    `;
                }).join('');

                // Attach inspect listeners
                elements.historyModalContent.querySelectorAll('.btn-inspect-history').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        const target = e.currentTarget;
                        displayVerificationResult({
                            verdict: target.dataset.verdict,
                            confidence: parseInt(target.dataset.conf, 10),
                            explanation: decodeURIComponent(target.dataset.exp),
                            source_document: decodeURIComponent(target.dataset.src) || null,
                            page_number: target.dataset.page ? parseInt(target.dataset.page, 10) : null,
                            row_number: target.dataset.row ? parseInt(target.dataset.row, 10) : null,
                            supporting_evidence: decodeURIComponent(target.dataset.evidence)
                        });
                        if (elements.claimInput) {
                            elements.claimInput.value = decodeURIComponent(target.dataset.claim);
                        }
                        elements.historyModal.classList.add('hidden');
                        elements.historyModal.classList.remove('flex');
                    });
                });
            }
        } catch (err) {
            elements.historyModalContent.innerHTML = `<div class="p-6 text-center text-red-500">Failed to load history: ${err.message}</div>`;
        }
    }

    // Sign out & Clear Session
    async function clearAndResetSession() {
        if (!confirm('Are you sure you want to start a fresh session? All uploaded reference documents and temporary history will be wiped.')) {
            return;
        }

        try {
            await fetch('/api/session/clear', {
                method: 'POST',
                headers: { 'X-Session-ID': sessionId }
            });
        } catch (err) {
            console.warn(err);
        }

        // Reset in-memory state
        stagedFiles = [];
        processedDocs = [];
        lastRetrievedChunks = [];
        currentResult = null;

        if (elements.claimInput) elements.claimInput.value = '';
        renderFileList();
        updateStatsDisplay({ documents_uploaded: 0, claims_verified: 0, fake_claims_detected: 0, average_confidence: 0 });

        // Reset verification card to default state
        displayVerificationResult({
            verdict: 'NOT ENOUGH EVIDENCE',
            confidence: 0,
            explanation: 'Upload reference documents and verify a claim to see analysis here.',
            source_document: 'No document loaded',
            supporting_evidence: 'Upload reference documents above to begin verification.'
        });

        showToast('Temporary session data wiped. Ready for new documents.', 'info');
    }

    // Setup drag-and-drop & file picker events
    function setupUploadEvents() {
        if (!elements.dropZone || !elements.fileInput) return;

        elements.dropZone.addEventListener('click', () => {
            elements.fileInput.click();
        });

        elements.fileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files.length > 0) {
                stageFiles(Array.from(e.target.files));
                e.target.value = ''; // reset so same file can be re-selected if removed
            }
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            elements.dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                elements.dropZone.classList.add('border-primary', 'bg-surface-container-highest/60');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            elements.dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                elements.dropZone.classList.remove('border-primary', 'bg-surface-container-highest/60');
            }, false);
        });

        elements.dropZone.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            if (dt && dt.files && dt.files.length > 0) {
                stageFiles(Array.from(dt.files));
            }
        }, false);
    }

    // Setup navigation & button click bindings
    function setupBindings() {
        // Process documents button
        if (elements.btnProcessDocs) {
            elements.btnProcessDocs.addEventListener('click', processStagedDocuments);
        }

        // Verify claim button
        if (elements.btnVerifyClaim) {
            elements.btnVerifyClaim.addEventListener('click', verifyClaim);
        }

        // Claim input Enter key (Ctrl+Enter or Cmd+Enter to submit)
        if (elements.claimInput) {
            elements.claimInput.addEventListener('keydown', (e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                    e.preventDefault();
                    verifyClaim();
                }
            });
        }

        // Evidence modal buttons
        if (elements.btnViewEvidence) {
            elements.btnViewEvidence.addEventListener('click', openEvidenceModal);
        }
        if (elements.evidenceModalClose) {
            elements.evidenceModalClose.addEventListener('click', () => {
                elements.evidenceModal.classList.add('hidden');
                elements.evidenceModal.classList.remove('flex');
            });
        }

        // History modal buttons
        elements.navHistory.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                openHistoryModal();
            });
        });
        if (elements.historyModalClose) {
            elements.historyModalClose.addEventListener('click', () => {
                elements.historyModal.classList.add('hidden');
                elements.historyModal.classList.remove('flex');
            });
        }

        // Help modal buttons
        elements.navHelp.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                if (elements.helpModal) {
                    elements.helpModal.classList.remove('hidden');
                    elements.helpModal.classList.add('flex');
                }
            });
        });
        if (elements.helpModalClose) {
            elements.helpModalClose.addEventListener('click', () => {
                elements.helpModal.classList.add('hidden');
                elements.helpModal.classList.remove('flex');
            });
        }

        // Sign Out buttons
        elements.navSignOut.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                clearAndResetSession();
            });
        });

        // Navigation scroll helpers
        elements.navDashboard.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });

        elements.navVerify.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                if (elements.claimInput) {
                    elements.claimInput.scrollIntoView({ behavior: 'smooth' });
                    elements.claimInput.focus();
                }
            });
        });

        elements.navUpload.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                if (elements.dropZone) {
                    elements.dropZone.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });

        elements.navStats.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const statsRow = document.querySelector('section.grid.grid-cols-1');
                if (statsRow) statsRow.scrollIntoView({ behavior: 'smooth' });
            });
        });

        if (elements.btnGetStarted) {
            elements.btnGetStarted.addEventListener('click', () => {
                if (elements.dropZone) {
                    elements.dropZone.scrollIntoView({ behavior: 'smooth' });
                }
            });
        }

        // Close modals on backdrop click
        [elements.evidenceModal, elements.historyModal, elements.helpModal].forEach(modal => {
            if (modal) {
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        modal.classList.add('hidden');
                        modal.classList.remove('flex');
                    }
                });
            }
        });
    }

    // Startup
    document.addEventListener('DOMContentLoaded', () => {
        setupUploadEvents();
        setupBindings();
        initSession();
    });

})();
