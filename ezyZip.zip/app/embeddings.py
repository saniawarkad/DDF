import re
import math
import hashlib
import numpy as np
import httpx
from typing import List, Optional
from app.config import settings

EMBEDDING_DIM = 768

def local_text_embedding(text: str, dim: int = EMBEDDING_DIM) -> np.ndarray:
    """
    Generate a high-quality deterministic pseudo-dense semantic embedding
    using multi-gram term frequency and locality-sensitive feature hashing.
    Used as reliable fallback when external embedding API is unavailable.
    """
    vec = np.zeros(dim, dtype=np.float32)
    cleaned = text.lower().strip()
    words = re.findall(r'\b[a-z0-9_\-]{2,}\b', cleaned)
    
    if not words:
        return vec

    # Word unigrams and bigrams
    tokens = list(words)
    for i in range(len(words) - 1):
        tokens.append(f"{words[i]}_{words[i+1]}")
    
    # Substring character n-grams (3 to 5 chars) for morphology
    for w in words:
        if len(w) >= 3:
            for n in [3, 4]:
                for i in range(len(w) - n + 1):
                    tokens.append(f"#{w[i:i+n]}")

    for token in tokens:
        # Generate hash index and sign using two independent hash algorithms
        h1 = int(hashlib.md5(token.encode('utf-8')).hexdigest()[:8], 16)
        h2 = int(hashlib.sha256(token.encode('utf-8')).hexdigest()[:8], 16)
        
        idx = h1 % dim
        sign = 1.0 if (h2 % 2 == 0) else -1.0
        
        # Word length weighting: longer words generally carry more semantic signal
        weight = 1.0 + math.log(max(1, len(token)))
        vec[idx] += sign * weight

    # L2 normalize
    norm = np.linalg.norm(vec)
    if norm > 1e-9:
        vec = vec / norm

    return vec


def get_gemini_embeddings_batch(texts: List[str], api_key: str) -> Optional[List[np.ndarray]]:
    """Generate embeddings using Google Gemini text-embedding-004 batch API."""
    if not api_key or not texts:
        return None

    url = "https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:batchEmbedContents"
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": api_key
    }
    
    # Limit batch size to 50 items per call
    batch_size = 50
    all_embeddings: List[np.ndarray] = []
    
    try:
        with httpx.Client(timeout=15.0) as client:
            for i in range(0, len(texts), batch_size):
                chunk_slice = texts[i:i + batch_size]
                requests_payload = [
                    {
                        "model": "models/text-embedding-004",
                        "content": {"parts": [{"text": t[:2048]}]}
                    }
                    for t in chunk_slice
                ]
                
                resp = client.post(url, headers=headers, json={"requests": requests_payload})
                if resp.status_code == 200:
                    data = resp.json()
                    embeddings_data = data.get("embeddings", [])
                    for item in embeddings_data:
                        values = item.get("values", [])
                        if values:
                            arr = np.array(values, dtype=np.float32)
                            norm = np.linalg.norm(arr)
                            if norm > 1e-9:
                                arr = arr / norm
                            all_embeddings.append(arr)
                        else:
                            all_embeddings.append(local_text_embedding(texts[len(all_embeddings)]))
                else:
                    # If batch API fails, fall back to local embeddings for remaining
                    return None
        return all_embeddings
    except Exception:
        return None


def generate_embeddings(texts: List[str]) -> List[np.ndarray]:
    """
    Generate L2-normalized embeddings for a list of texts.
    Attempts Google Gemini text-embedding-004 if key is present,
    otherwise uses local deterministic feature vectorizer.
    """
    if not texts:
        return []

    # If GEMINI_API_KEY is configured, attempt Gemini text-embedding-004
    if settings.GEMINI_API_KEY and len(settings.GEMINI_API_KEY) > 10:
        gemini_vecs = get_gemini_embeddings_batch(texts, settings.GEMINI_API_KEY)
        if gemini_vecs and len(gemini_vecs) == len(texts):
            return gemini_vecs

    # Fallback to local feature vectorizer
    return [local_text_embedding(t) for t in texts]


def generate_single_embedding(text: str) -> np.ndarray:
    """Generate embedding for a single text (e.g. query claim)."""
    res = generate_embeddings([text])
    if res:
        return res[0]
    return np.zeros(EMBEDDING_DIM, dtype=np.float32)
