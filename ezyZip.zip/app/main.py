import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.api.routes import router as api_router
from app.session_manager import session_manager

# Background task for periodic session memory cleanup
async def periodic_session_cleanup():
    while True:
        try:
            await asyncio.sleep(settings.CLEANUP_INTERVAL_SECONDS)
            session_manager.cleanup_expired_sessions()
        except asyncio.CancelledError:
            break
        except Exception:
            pass

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: spawn periodic cleanup task
    cleanup_task = asyncio.create_task(periodic_session_cleanup())
    yield
    # Shutdown: cancel cleanup task
    cleanup_task.cancel()
    try:
        await cleanup_task
    except asyncio.CancelledError:
        pass

app = FastAPI(
    title="FKNews – AI Fake News Verification System",
    description="Backend API and web application for verifying news claims against reference documents using Google Gemini.",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for pair programming and cross-origin access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(api_router)

# Mount static folder
static_path = Path(__file__).resolve().parent.parent / "static"
static_path.mkdir(parents=True, exist_ok=True)

@app.get("/")
async def serve_index():
    index_file = static_path / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {"message": "FKNews backend is running. Please ensure index.html exists in static folder."}

app.mount("/static", StaticFiles(directory=str(static_path)), name="static")

# Custom Exception Handler to return clean JSON errors
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "error": True,
            "message": "An internal server error occurred while processing your request.",
            "detail": str(exc)
        }
    )
