import time
import uuid
import threading
from typing import Dict, List, Any, Optional
from app.config import settings
from app.vector_store import FAISSVectorStore

class UserSession:
    """
    Ephemeral in-memory session container.
    Holds uploaded document metadata, vector index, and verification history.
    Stored strictly in RAM; never written to persistent disk or database.
    """
    def __init__(self, session_id: str):
        self.session_id: str = session_id
        self.created_at: float = time.time()
        self.last_accessed: float = time.time()
        self.documents: Dict[str, Dict[str, Any]] = {}
        self.vector_store: FAISSVectorStore = FAISSVectorStore()
        self.history: List[Dict[str, Any]] = []

    def touch(self):
        """Update last accessed timestamp."""
        self.last_accessed = time.time()

    def add_document_record(self, doc_name: str, doc_type: str, file_size: int, chunk_count: int):
        self.touch()
        self.documents[doc_name] = {
            "doc_name": doc_name,
            "doc_type": doc_type,
            "file_size": file_size,
            "chunk_count": chunk_count,
            "uploaded_at": time.time(),
            "status": "Processed"
        }

    def remove_document_record(self, doc_name: str):
        self.touch()
        if doc_name in self.documents:
            del self.documents[doc_name]
        self.vector_store.remove_document(doc_name)

    def add_verification_record(self, result: Dict[str, Any]):
        self.touch()
        record = {
            "id": str(uuid.uuid4()),
            "timestamp": time.time(),
            "claim": result.get("claim", ""),
            "verdict": result.get("verdict", "NOT ENOUGH EVIDENCE"),
            "confidence": result.get("confidence", 0),
            "explanation": result.get("explanation", ""),
            "supporting_evidence": result.get("supporting_evidence", ""),
            "source_document": result.get("source_document"),
            "page_number": result.get("page_number"),
            "row_number": result.get("row_number"),
            "retrieved_chunks_count": len(result.get("retrieved_chunks", []))
        }
        self.history.append(record)

    def get_stats(self) -> Dict[str, Any]:
        self.touch()
        claims_count = len(self.history)
        fake_count = sum(1 for h in self.history if h.get("verdict") == "FALSE")
        avg_conf = 0
        if claims_count > 0:
            avg_conf = int(sum(h.get("confidence", 0) for h in self.history) / claims_count)

        return {
            "documents_uploaded": len(self.documents),
            "total_chunks": self.vector_store.total_chunks,
            "claims_verified": claims_count,
            "fake_claims_detected": fake_count,
            "average_confidence": avg_conf
        }

    def clear(self):
        """Wipe all session data from RAM."""
        self.documents.clear()
        self.vector_store.clear()
        self.history.clear()
        self.touch()


class SessionManager:
    """Thread-safe manager for ephemeral user sessions with TTL cleanup."""
    def __init__(self, ttl_seconds: int = settings.SESSION_TTL_SECONDS):
        self.ttl_seconds = ttl_seconds
        self._sessions: Dict[str, UserSession] = {}
        self._lock = threading.Lock()

    def create_session(self, session_id: Optional[str] = None) -> UserSession:
        """Create a fresh user session with a unique UUID or specified ID."""
        with self._lock:
            sid = session_id or str(uuid.uuid4())
            session = UserSession(sid)
            self._sessions[sid] = session
            return session

    def get_session(self, session_id: str) -> Optional[UserSession]:
        """Retrieve existing session if valid and not expired."""
        with self._lock:
            session = self._sessions.get(session_id)
            if session:
                if (time.time() - session.last_accessed) > self.ttl_seconds:
                    session.clear()
                    del self._sessions[session_id]
                    return None
                session.touch()
                return session
            return None

    def get_or_create_session(self, session_id: Optional[str] = None) -> UserSession:
        """Get existing session or initialize a new one if not found or expired."""
        if session_id:
            existing = self.get_session(session_id)
            if existing:
                return existing
            return self.create_session(session_id)

        return self.create_session()

    def delete_session(self, session_id: str):
        """Explicitly clear and delete a session."""
        with self._lock:
            if session_id in self._sessions:
                self._sessions[session_id].clear()
                del self._sessions[session_id]

    def cleanup_expired_sessions(self) -> int:
        """Purge sessions that have exceeded the TTL limit."""
        with self._lock:
            now = time.time()
            expired_keys = [
                sid for sid, s in self._sessions.items()
                if (now - s.last_accessed) > self.ttl_seconds
            ]
            for sid in expired_keys:
                self._sessions[sid].clear()
                del self._sessions[sid]
            return len(expired_keys)

# Global singleton session manager
session_manager = SessionManager()
