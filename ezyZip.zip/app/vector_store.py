import faiss
import numpy as np
from typing import List, Dict, Any, Tuple, Optional
from app.config import settings
from app.document_processing import DocumentChunk
from app.embeddings import EMBEDDING_DIM, generate_embeddings, generate_single_embedding

class FAISSVectorStore:
    """
    In-memory FAISS vector store strictly tied to a user session.
    Stores chunk embeddings and provides cosine similarity search.
    Data is stored in RAM only and discarded upon session termination.
    """
    def __init__(self, dimension: int = EMBEDDING_DIM):
        self.dimension = dimension
        self.chunks: List[DocumentChunk] = []
        # IndexFlatIP computes inner product, which equals cosine similarity for L2-normalized vectors
        self.index = faiss.IndexFlatIP(self.dimension)

    def add_chunks(self, new_chunks: List[DocumentChunk]) -> int:
        """Embed and add a list of DocumentChunk objects into FAISS index."""
        if not new_chunks:
            return 0

        texts = [chunk.text for chunk in new_chunks]
        embeddings = generate_embeddings(texts)
        if not embeddings:
            return 0

        matrix = np.array(embeddings, dtype=np.float32)
        if matrix.ndim == 1:
            matrix = matrix.reshape(1, -1)

        # Ensure L2 normalization for exact cosine similarity
        faiss.normalize_L2(matrix)

        self.index.add(matrix)
        self.chunks.extend(new_chunks)
        return len(new_chunks)

    def search(self, query: str, top_k: int = settings.TOP_K_CHUNKS) -> List[Dict[str, Any]]:
        """
        Search for top_k most relevant chunks matching the query string.
        Returns chunk metadata along with similarity score.
        """
        if self.index.ntotal == 0 or not self.chunks:
            return []

        k = min(top_k, self.index.ntotal)
        query_vec = generate_single_embedding(query)
        matrix = np.array([query_vec], dtype=np.float32)
        faiss.normalize_L2(matrix)

        distances, indices = self.index.search(matrix, k)

        results = []
        for rank in range(k):
            idx = int(indices[0][rank])
            score = float(distances[0][rank])
            if 0 <= idx < len(self.chunks):
                chunk = self.chunks[idx]
                chunk_dict = chunk.to_dict()
                chunk_dict["similarity_score"] = round(max(0.0, min(1.0, score)), 4)
                results.append(chunk_dict)

        return results

    def remove_document(self, doc_name: str) -> int:
        """Remove all chunks from a specific document and rebuild in-memory index."""
        remaining_chunks = [c for c in self.chunks if c.doc_name != doc_name]
        removed_count = len(self.chunks) - len(remaining_chunks)
        
        # Reset and rebuild FAISS index with remaining chunks
        self.clear()
        if remaining_chunks:
            self.add_chunks(remaining_chunks)
            
        return removed_count

    def clear(self):
        """Reset the in-memory FAISS index and discard all stored chunks."""
        self.chunks.clear()
        self.index = faiss.IndexFlatIP(self.dimension)

    @property
    def total_chunks(self) -> int:
        return len(self.chunks)

    def get_document_summary(self) -> List[Dict[str, Any]]:
        """Return summary of all currently indexed documents."""
        docs: Dict[str, Dict[str, Any]] = {}
        for chunk in self.chunks:
            name = chunk.doc_name
            if name not in docs:
                docs[name] = {
                    "doc_name": name,
                    "doc_type": chunk.doc_type,
                    "total_chunks": 0,
                    "pages": set(),
                    "rows": set()
                }
            docs[name]["total_chunks"] += 1
            if chunk.page_number is not None:
                docs[name]["pages"].add(chunk.page_number)
            if chunk.row_number is not None:
                docs[name]["rows"].add(chunk.row_number)

        summary = []
        for name, data in docs.items():
            summary.append({
                "doc_name": name,
                "doc_type": data["doc_type"],
                "total_chunks": data["total_chunks"],
                "page_count": len(data["pages"]) if data["pages"] else None,
                "row_count": len(data["rows"]) if data["rows"] else None,
            })
        return summary
