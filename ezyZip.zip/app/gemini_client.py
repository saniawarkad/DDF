import json
import re
import httpx
from typing import List, Dict, Any, Optional
from app.config import settings

VERIFICATION_SYSTEM_PROMPT = """You are an academic-grade AI Truth Arbiter and Fake News Verification specialist for the FKNews system.
Your mission is to objectively determine whether the User's News Claim is TRUE, FALSE, or NOT ENOUGH EVIDENCE strictly and exclusively based on the provided Reference Document Excerpts.

ABSOLUTE OPERATIONAL MANDATES:
1. STRICT CLOSED-WORLD ASSUMPTION: You must evaluate the claim EXCLUSIVELY using the facts explicitly stated in the Reference Context.
2. ZERO EXTERNAL KNOWLEDGE: Even if you know something is true or false in the real world, if it is NOT stated in or deducible from the provided reference documents, you CANNOT use it.
3. NO FABRICATION: Never invent, extrapolate, or embellish facts, citations, numbers, or quotes.
4. MANDATORY VERDICT TAXONOMY:
   - "TRUE": The reference excerpts directly, unambiguously substantiate and confirm the claim.
   - "FALSE": The reference excerpts directly contradict, refute, or disprove the claim.
   - "NOT ENOUGH EVIDENCE": The reference excerpts do not mention the claim or do not provide sufficient factual evidence to either substantiate or refute it.
5. EXPLANATION: Clearly explain why the context supports, contradicts, or fails to address the claim.
6. SUPPORTING EVIDENCE: Quote the exact verbatim sentence(s) or provide the exact data from the context that justifies your verdict. If verdict is "NOT ENOUGH EVIDENCE", state: "No conclusive evidence found in uploaded reference context."
7. SOURCE CITATION: Specify the document name and page number or CSV row number where the evidence is located. If none, set to null.

You must respond with valid JSON ONLY according to this exact schema:
{
  "verdict": "TRUE" | "FALSE" | "NOT ENOUGH EVIDENCE",
  "confidence": <integer between 0 and 100 representing certainty based strictly on reference context clarity>,
  "explanation": "<Concise, authoritative analysis explaining how the reference context confirms, refutes, or lacks evidence for the claim>",
  "supporting_evidence": "<Direct quotation or excerpt from the provided text>",
  "source_document": "<Filename of document with the evidence, or null>",
  "page_number": <Integer page number or null>,
  "row_number": <Integer row number or null>
}
"""

def format_context_for_prompt(chunks: List[Dict[str, Any]]) -> str:
    """Format retrieved document chunks with clear source headers for Gemini."""
    if not chunks:
        return "No reference document context available."

    formatted = []
    for idx, chunk in enumerate(chunks, 1):
        doc_name = chunk.get("doc_name", "Unknown Document")
        doc_type = chunk.get("doc_type", "doc")
        page = chunk.get("page_number")
        row = chunk.get("row_number")
        score = chunk.get("similarity_score", 0.0)

        location_tag = ""
        if doc_type == "pdf" and page is not None:
            location_tag = f"Page {page}"
        elif doc_type == "csv" and row is not None:
            location_tag = f"Row {row}"
        else:
            location_tag = "General Context"

        formatted.append(
            f"--- REFERENCE EXCERPT {idx} [{doc_name} | {location_tag} | Relevance: {int(score*100)}%] ---\n"
            f"{chunk.get('text', '').strip()}\n"
        )

    return "\n".join(formatted)


def clean_gemini_json_response(raw_text: str) -> Dict[str, Any]:
    """Clean and parse JSON from Gemini output, handling potential markdown code blocks."""
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    cleaned = cleaned.strip()

    try:
        data = json.loads(cleaned)
        # Ensure verdict is valid
        verdict = str(data.get("verdict", "")).strip().upper()
        if "TRUE" in verdict and "NOT" not in verdict:
            data["verdict"] = "TRUE"
        elif "FALSE" in verdict or "FAKE" in verdict:
            data["verdict"] = "FALSE"
        else:
            data["verdict"] = "NOT ENOUGH EVIDENCE"

        # Ensure confidence is integer 0-100
        try:
            conf = int(data.get("confidence", 80))
            data["confidence"] = max(0, min(100, conf))
        except (ValueError, TypeError):
            data["confidence"] = 75

        return data
    except Exception:
        # Fallback regex extraction if raw JSON fails
        verdict = "NOT ENOUGH EVIDENCE"
        if re.search(r'"verdict"\s*:\s*"TRUE"', raw_text, re.IGNORECASE):
            verdict = "TRUE"
        elif re.search(r'"verdict"\s*:\s*"FALSE"', raw_text, re.IGNORECASE):
            verdict = "FALSE"

        return {
            "verdict": verdict,
            "confidence": 70,
            "explanation": "Extracted from AI arbiter evaluation of reference context.",
            "supporting_evidence": "Refer to context excerpts.",
            "source_document": None,
            "page_number": None,
            "row_number": None
        }


async def verify_claim_with_gemini(
    claim: str,
    retrieved_chunks: List[Dict[str, Any]],
    api_key: Optional[str] = None,
    model_name: Optional[str] = None
) -> Dict[str, Any]:
    """
    Verify a claim against retrieved reference chunks using Google Gemini API.
    Enforces strict reference-only verification.
    """
    key = (api_key or settings.GEMINI_API_KEY).strip()
    model = (model_name or settings.GEMINI_MODEL).strip() or "gemini-3.1-flash-lite"

    # Security check: Never proceed without an API key
    if not key or key == "your_gemini_api_key_here":
        return {
            "error": True,
            "error_code": "GEMINI_API_KEY_MISSING",
            "message": "Google Gemini API key is not configured. Please set GEMINI_API_KEY in your .env file or backend environment to verify claims.",
            "verdict": "NOT ENOUGH EVIDENCE",
            "confidence": 0,
            "explanation": "Verification halted: GEMINI_API_KEY is not configured on the backend.",
            "supporting_evidence": "Backend configuration required: please provide a valid Google Gemini API key.",
            "source_document": None,
            "page_number": None,
            "row_number": None,
            "retrieved_chunks": retrieved_chunks
        }

    # If no reference context was retrieved
    if not retrieved_chunks:
        return {
            "error": False,
            "verdict": "NOT ENOUGH EVIDENCE",
            "confidence": 0,
            "explanation": "No relevant reference document context was found matching the claim in the uploaded documents.",
            "supporting_evidence": "No reference documents matched the query claim.",
            "source_document": None,
            "page_number": None,
            "row_number": None,
            "retrieved_chunks": []
        }

    formatted_context = format_context_for_prompt(retrieved_chunks)

    user_prompt = f"""CLAIM TO VERIFY:
"{claim}"

REFERENCE CONTEXT FROM UPLOADED DOCUMENTS:
{formatted_context}

INSTRUCTIONS:
Evaluate whether the claim is supported or contradicted solely by the reference context above. Remember: If the reference context does not contain sufficient facts to verify or disprove the claim, return "NOT ENOUGH EVIDENCE". Return JSON according to the schema."""

    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [{"text": f"{VERIFICATION_SYSTEM_PROMPT}\n\n{user_prompt}"}]
            }
        ],
        "generationConfig": {
            "temperature": 0.1,
            "maxOutputTokens": 1024,
            "responseMimeType": "application/json"
        }
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": key
    }

    try:
        async with httpx.AsyncClient(timeout=35.0) as client:
            resp = await client.post(url, headers=headers, json=payload)

            if resp.status_code == 200:
                result_json = resp.json()
                try:
                    candidates = result_json.get("candidates", [])
                    if candidates and "content" in candidates[0]:
                        parts = candidates[0]["content"].get("parts", [])
                        if parts:
                            raw_text = parts[0].get("text", "")
                            parsed = clean_gemini_json_response(raw_text)
                            parsed["error"] = False
                            parsed["retrieved_chunks"] = retrieved_chunks
                            
                            # Sanity fill citation if model omitted it but top chunk exists
                            if not parsed.get("source_document") and retrieved_chunks:
                                top_c = retrieved_chunks[0]
                                parsed["source_document"] = top_c.get("doc_name")
                                parsed["page_number"] = top_c.get("page_number")
                                parsed["row_number"] = top_c.get("row_number")
                                
                            return parsed

                    return {
                        "error": True,
                        "error_code": "EMPTY_GEMINI_RESPONSE",
                        "message": "Gemini API returned an empty candidate list.",
                        "verdict": "NOT ENOUGH EVIDENCE",
                        "confidence": 0,
                        "explanation": "No response text was generated by the AI model.",
                        "supporting_evidence": "Response generation failed.",
                        "source_document": None,
                        "page_number": None,
                        "row_number": None,
                        "retrieved_chunks": retrieved_chunks
                    }
                except Exception as ex:
                    return {
                        "error": True,
                        "error_code": "PARSE_ERROR",
                        "message": f"Failed to parse Gemini response: {str(ex)}",
                        "verdict": "NOT ENOUGH EVIDENCE",
                        "confidence": 0,
                        "explanation": "Error formatting AI model verification output.",
                        "supporting_evidence": "JSON parsing error.",
                        "source_document": None,
                        "page_number": None,
                        "row_number": None,
                        "retrieved_chunks": retrieved_chunks
                    }

            elif resp.status_code == 400:
                err_detail = resp.json().get("error", {}).get("message", "Bad Request")
                return {
                    "error": True,
                    "error_code": "GEMINI_BAD_REQUEST",
                    "message": f"Google Gemini API error (400): {err_detail}",
                    "verdict": "NOT ENOUGH EVIDENCE",
                    "confidence": 0,
                    "explanation": f"Google Gemini API rejected the request: {err_detail}",
                    "supporting_evidence": "API error.",
                    "source_document": None,
                    "page_number": None,
                    "row_number": None,
                    "retrieved_chunks": retrieved_chunks
                }
            elif resp.status_code in (401, 403):
                return {
                    "error": True,
                    "error_code": "INVALID_API_KEY",
                    "message": "Google Gemini API key is invalid or unauthorized. Please verify your GEMINI_API_KEY.",
                    "verdict": "NOT ENOUGH EVIDENCE",
                    "confidence": 0,
                    "explanation": "Authorization failed: Invalid Google Gemini API Key.",
                    "supporting_evidence": "Check your GEMINI_API_KEY in the .env file.",
                    "source_document": None,
                    "page_number": None,
                    "row_number": None,
                    "retrieved_chunks": retrieved_chunks
                }
            elif resp.status_code == 429:
                return {
                    "error": True,
                    "error_code": "RATE_LIMITED",
                    "message": "Google Gemini API rate limit or quota exceeded. Please wait a moment and try again.",
                    "verdict": "NOT ENOUGH EVIDENCE",
                    "confidence": 0,
                    "explanation": "Gemini API rate limit reached (429).",
                    "supporting_evidence": "Rate limit exceeded.",
                    "source_document": None,
                    "page_number": None,
                    "row_number": None,
                    "retrieved_chunks": retrieved_chunks
                }
            else:
                return {
                    "error": True,
                    "error_code": f"HTTP_{resp.status_code}",
                    "message": f"Gemini API returned HTTP status {resp.status_code}.",
                    "verdict": "NOT ENOUGH EVIDENCE",
                    "confidence": 0,
                    "explanation": f"Gemini service responded with status {resp.status_code}.",
                    "supporting_evidence": "Service error.",
                    "source_document": None,
                    "page_number": None,
                    "row_number": None,
                    "retrieved_chunks": retrieved_chunks
                }

    except httpx.TimeoutException:
        return {
            "error": True,
            "error_code": "TIMEOUT",
            "message": "Request to Google Gemini API timed out after 35 seconds. Please try again.",
            "verdict": "NOT ENOUGH EVIDENCE",
            "confidence": 0,
            "explanation": "Network timeout occurred while contacting Google Gemini.",
            "supporting_evidence": "Timeout error.",
            "source_document": None,
            "page_number": None,
            "row_number": None,
            "retrieved_chunks": retrieved_chunks
        }
    except Exception as e:
        return {
            "error": True,
            "error_code": "NETWORK_ERROR",
            "message": f"Connection error contacting Gemini API: {str(e)}",
            "verdict": "NOT ENOUGH EVIDENCE",
            "confidence": 0,
            "explanation": "Failed to connect to AI verification service.",
            "supporting_evidence": "Network communication failure.",
            "source_document": None,
            "page_number": None,
            "row_number": None,
            "retrieved_chunks": retrieved_chunks
        }
