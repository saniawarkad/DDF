from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class ClaimVerificationRequest(BaseModel):
    claim: str = Field(..., min_length=3, max_length=2000, description="The news claim or question to verify against uploaded documents.")

class DocumentInfo(BaseModel):
    doc_name: str
    doc_type: str
    file_size: int
    chunk_count: int
    uploaded_at: float
    status: str

class VerificationResponse(BaseModel):
    verdict: str
    confidence: int
    explanation: str
    supporting_evidence: str
    source_document: Optional[str] = None
    page_number: Optional[int] = None
    row_number: Optional[int] = None
    total_documents_analyzed: int = 0
    retrieved_chunks: List[Dict[str, Any]] = []
    error: bool = False
    message: Optional[str] = None

class UploadResponse(BaseModel):
    success: bool
    message: str
    documents: List[Dict[str, Any]]
    total_chunks: int

class SessionStatusResponse(BaseModel):
    session_id: str
    active: bool
    stats: Dict[str, Any]
    documents: List[Dict[str, Any]]

class HistoryResponse(BaseModel):
    history: List[Dict[str, Any]]
