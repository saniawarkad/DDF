from fastapi import APIRouter, UploadFile, File, Header, HTTPException, status
from typing import List, Optional
import os

from app.config import settings
from app.session_manager import session_manager
from app.document_processing import process_document, sanitize_filename
from app.gemini_client import verify_claim_with_gemini
from app.api.schemas import (
    ClaimVerificationRequest,
    VerificationResponse,
    UploadResponse,
    SessionStatusResponse,
    HistoryResponse
)

router = APIRouter(prefix="/api", tags=["Verification"])

def get_session_from_header(x_session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    """Helper to retrieve or initialize ephemeral session from request header."""
    return session_manager.get_or_create_session(x_session_id)


@router.get("/health")
async def health_check():
    """Health check endpoint exposing system status and Gemini configuration status."""
    return {
        "status": "healthy",
        "gemini_model": settings.GEMINI_MODEL,
        "gemini_api_key_configured": bool(settings.GEMINI_API_KEY and len(settings.GEMINI_API_KEY) > 10),
        "max_upload_size_mb": settings.MAX_UPLOAD_SIZE_MB,
        "allowed_formats": list(settings.ALLOWED_EXTENSIONS)
    }


@router.post("/session/init", response_model=SessionStatusResponse)
async def init_session(x_session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    """Initialize a new clean session or retrieve current session status."""
    session = get_session_from_header(x_session_id)
    doc_summary = session.vector_store.get_document_summary()
    return SessionStatusResponse(
        session_id=session.session_id,
        active=True,
        stats=session.get_stats(),
        documents=doc_summary
    )


@router.post("/session/clear")
async def clear_session(x_session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    """Wipe all temporary data (documents, embeddings, and history) for the current session."""
    session = get_session_from_header(x_session_id)
    session.clear()
    return {
        "success": True,
        "message": "Current session data wiped from memory.",
        "session_id": session.session_id
    }


@router.post("/documents/upload", response_model=UploadResponse)
async def upload_documents(
    files: List[UploadFile] = File(...),
    x_session_id: Optional[str] = Header(None, alias="X-Session-ID")
):
    """
    Upload and process reference PDF and CSV documents into ephemeral memory.
    Extracts text with page/row metadata, splits into chunks, and indexes into FAISS.
    """
    session = get_session_from_header(x_session_id)

    if not files:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No files were provided for upload."
        )

    processed_docs = []
    total_new_chunks = 0
    errors = []

    for file in files:
        filename = sanitize_filename(file.filename or "unknown_file")
        ext = os.path.splitext(filename)[1].lower()

        if ext not in settings.ALLOWED_EXTENSIONS:
            errors.append(f"'{filename}' has an unsupported file format. Only PDF and CSV are permitted.")
            continue

        try:
            # Read file content safely in chunks to enforce size limit before buffering
            contents = bytearray()
            chunk_size = 1024 * 1024  # 1MB chunks
            while chunk := await file.read(chunk_size):
                contents.extend(chunk)
                if len(contents) > settings.MAX_UPLOAD_SIZE_BYTES:
                    raise ValueError(f"File size exceeds maximum limit of {settings.MAX_UPLOAD_SIZE_MB}MB.")

            file_bytes = bytes(contents)
            
            # Process and chunk document (extracting page or row numbers)
            chunks = process_document(filename, file_bytes)
            
            if not chunks:
                errors.append(f"'{filename}' did not yield any readable text or rows.")
                continue

            # Add chunks to session FAISS vector store
            indexed_count = session.vector_store.add_chunks(chunks)
            total_new_chunks += indexed_count

            # Record document in session
            doc_type = "pdf" if ext == ".pdf" else "csv"
            session.add_document_record(
                doc_name=filename,
                doc_type=doc_type,
                file_size=len(file_bytes),
                chunk_count=indexed_count
            )

            processed_docs.append({
                "doc_name": filename,
                "doc_type": doc_type,
                "chunk_count": indexed_count,
                "file_size": len(file_bytes),
                "status": "Processed"
            })

        except Exception as e:
            errors.append(f"Error processing '{filename}': {str(e)}")

    if not processed_docs and errors:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="; ".join(errors)
        )

    msg = f"Successfully processed {len(processed_docs)} document(s) ({total_new_chunks} context chunks indexed into FAISS)."
    if errors:
        msg += f" Note: {'; '.join(errors)}"

    return UploadResponse(
        success=True,
        message=msg,
        documents=processed_docs,
        total_chunks=session.vector_store.total_chunks
    )


@router.get("/documents")
async def list_documents(x_session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    """List documents currently loaded in the temporary session."""
    session = get_session_from_header(x_session_id)
    return {
        "documents": session.vector_store.get_document_summary(),
        "total_chunks": session.vector_store.total_chunks
    }


@router.delete("/documents/{doc_name}")
async def delete_document(
    doc_name: str,
    x_session_id: Optional[str] = Header(None, alias="X-Session-ID")
):
    """Remove a document and its chunks from the session vector store."""
    session = get_session_from_header(x_session_id)
    sanitized = sanitize_filename(doc_name)
    session.remove_document_record(sanitized)
    return {
        "success": True,
        "message": f"Document '{sanitized}' removed from session memory.",
        "remaining_chunks": session.vector_store.total_chunks
    }


@router.post("/verify", response_model=VerificationResponse)
async def verify_claim(
    request: ClaimVerificationRequest,
    x_session_id: Optional[str] = Header(None, alias="X-Session-ID")
):
    """
    Verify a news claim against uploaded reference documents.
    1. Retrieves top relevant chunks from in-memory FAISS store.
    2. Sends claim and retrieved context to Google Gemini.
    3. Gemini strictly returns TRUE, FALSE, or NOT ENOUGH EVIDENCE.
    4. Records result in temporary session history.
    """
    session = get_session_from_header(x_session_id)
    claim = request.claim.strip()

    if not claim:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Claim cannot be empty. Please enter a claim or question to verify."
        )

    # Check if reference documents have been uploaded
    if session.vector_store.total_chunks == 0 or len(session.documents) == 0:
        return VerificationResponse(
            verdict="NOT ENOUGH EVIDENCE",
            confidence=0,
            explanation="No reference documents have been uploaded or processed in this session. FKNews evaluates claims strictly against your reference materials. Please upload and process PDF or CSV documents first.",
            supporting_evidence="No reference context available in session.",
            source_document=None,
            page_number=None,
            row_number=None,
            total_documents_analyzed=0,
            retrieved_chunks=[],
            error=False,
            message="No documents uploaded."
        )

    # Retrieve most relevant chunks from FAISS
    retrieved_chunks = session.vector_store.search(claim, top_k=settings.TOP_K_CHUNKS)

    # Call Gemini API with strict context prompt
    gemini_result = await verify_claim_with_gemini(claim, retrieved_chunks)

    # Build response
    verdict = gemini_result.get("verdict", "NOT ENOUGH EVIDENCE")
    confidence = gemini_result.get("confidence", 0)
    explanation = gemini_result.get("explanation", "")
    evidence = gemini_result.get("supporting_evidence", "")
    source_doc = gemini_result.get("source_document")
    page_num = gemini_result.get("page_number")
    row_num = gemini_result.get("row_number")
    is_error = gemini_result.get("error", False)
    error_msg = gemini_result.get("message")

    response_data = {
        "claim": claim,
        "verdict": verdict,
        "confidence": confidence,
        "explanation": explanation,
        "supporting_evidence": evidence,
        "source_document": source_doc,
        "page_number": page_num,
        "row_number": row_num,
        "total_documents_analyzed": len(session.documents),
        "retrieved_chunks": retrieved_chunks,
        "error": is_error,
        "message": error_msg
    }

    # Record in temporary session history
    session.add_verification_record(response_data)

    return VerificationResponse(
        verdict=verdict,
        confidence=confidence,
        explanation=explanation,
        supporting_evidence=evidence,
        source_document=source_doc,
        page_number=page_num,
        row_number=row_num,
        total_documents_analyzed=len(session.documents),
        retrieved_chunks=retrieved_chunks,
        error=is_error,
        message=error_msg
    )


@router.get("/history", response_model=HistoryResponse)
async def get_history(x_session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    """Get temporary verification history for current session."""
    session = get_session_from_header(x_session_id)
    return HistoryResponse(history=session.history)


@router.get("/stats")
async def get_stats(x_session_id: Optional[str] = Header(None, alias="X-Session-ID")):
    """Get dynamic statistics for the current session."""
    session = get_session_from_header(x_session_id)
    return session.get_stats()
