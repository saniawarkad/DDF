import io
import re
import csv
import uuid
from typing import List, Dict, Any, Optional
from pypdf import PdfReader
from app.config import settings

class DocumentChunk:
    def __init__(
        self,
        doc_name: str,
        doc_type: str,
        text: str,
        page_number: Optional[int] = None,
        row_number: Optional[int] = None,
        chunk_id: Optional[str] = None
    ):
        self.id = chunk_id or str(uuid.uuid4())
        self.doc_name = doc_name
        self.doc_type = doc_type  # 'pdf' or 'csv'
        self.page_number = page_number
        self.row_number = row_number
        self.text = text.strip()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "doc_name": self.doc_name,
            "doc_type": self.doc_type,
            "page_number": self.page_number,
            "row_number": self.row_number,
            "text": self.text,
            "source_citation": self.get_citation()
        }

    def get_citation(self) -> str:
        if self.doc_type == "pdf" and self.page_number is not None:
            return f"{self.doc_name} (Page {self.page_number})"
        elif self.doc_type == "csv" and self.row_number is not None:
            return f"{self.doc_name} (Row {self.row_number})"
        return self.doc_name


def sanitize_filename(filename: str) -> str:
    """Sanitize filename to prevent directory traversal and remove unsafe characters."""
    filename = filename.replace("\\", "/").split("/")[-1]
    # Keep alphanumeric, underscores, hyphens, and dots
    cleaned = re.sub(r'[^a-zA-Z0-9_\.-]', '_', filename)
    if not cleaned or cleaned.startswith('.'):
        cleaned = f"doc_{uuid.uuid4().hex[:8]}{cleaned}"
    return cleaned


def clean_text(text: str) -> str:
    """Normalize whitespace and strip non-printable characters."""
    if not text:
        return ""
    # Replace non-breaking spaces and other unicode spaces
    text = re.sub(r'[\r\f\v]', ' ', text)
    # Collapse multiple consecutive newlines or spaces
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[ \t]+', ' ', text)
    return text.strip()


def split_text_into_chunks(
    text: str,
    doc_name: str,
    doc_type: str,
    page_number: Optional[int] = None,
    row_number: Optional[int] = None,
    chunk_size: int = settings.CHUNK_SIZE,
    chunk_overlap: int = settings.CHUNK_OVERLAP
) -> List[DocumentChunk]:
    """Split text into overlapping chunks, attempting to break at sentences or paragraphs."""
    cleaned = clean_text(text)
    if not cleaned:
        return []

    # If short enough, return as single chunk
    if len(cleaned) <= chunk_size:
        return [DocumentChunk(doc_name, doc_type, cleaned, page_number, row_number)]

    chunks: List[DocumentChunk] = []
    start = 0
    text_len = len(cleaned)

    while start < text_len:
        end = start + chunk_size
        if end >= text_len:
            chunk_text = cleaned[start:].strip()
            if chunk_text:
                chunks.append(DocumentChunk(doc_name, doc_type, chunk_text, page_number, row_number))
            break

        # Look for natural sentence break (. ! ? \n) near the end
        cutoff = end
        sub = cleaned[start:end + 50]  # Look slightly ahead for sentence end
        sentence_end = -1
        for punct in ['. ', '.\n', '?\n', '? ', '!\n', '! ', '\n\n']:
            pos = sub.rfind(punct)
            if pos != -1 and pos > (chunk_size // 2):
                if pos > sentence_end:
                    sentence_end = pos + len(punct) - 1

        if sentence_end != -1:
            cutoff = start + sentence_end
        else:
            # Fall back to word boundary
            space_pos = cleaned.rfind(' ', start, end)
            if space_pos > start + (chunk_size // 2):
                cutoff = space_pos

        chunk_text = cleaned[start:cutoff].strip()
        if chunk_text:
            chunks.append(DocumentChunk(doc_name, doc_type, chunk_text, page_number, row_number))

        start = max(start + 1, cutoff - chunk_overlap)

    return chunks


def process_pdf_document(filename: str, file_bytes: bytes) -> List[DocumentChunk]:
    """Extract text from PDF file with page numbers and split into chunks."""
    # Check magic bytes for PDF
    if not file_bytes.startswith(b'%PDF'):
        raise ValueError("Invalid PDF format: file missing standard PDF header.")

    try:
        reader = PdfReader(io.BytesIO(file_bytes))
    except Exception as e:
        raise ValueError(f"Could not parse PDF file: {str(e)}")

    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception:
            raise ValueError("The uploaded PDF is password-protected and cannot be read.")

    total_pages = len(reader.pages)
    if total_pages == 0:
        raise ValueError("The uploaded PDF document contains 0 pages.")

    all_chunks: List[DocumentChunk] = []
    total_extracted_chars = 0

    for page_idx in range(total_pages):
        page = reader.pages[page_idx]
        page_num = page_idx + 1
        page_text = ""
        try:
            page_text = page.extract_text() or ""
        except Exception:
            page_text = ""

        page_text = clean_text(page_text)
        total_extracted_chars += len(page_text)

        if page_text:
            chunks = split_text_into_chunks(
                text=page_text,
                doc_name=filename,
                doc_type="pdf",
                page_number=page_num
            )
            all_chunks.extend(chunks)

    if total_extracted_chars == 0 or not all_chunks:
        raise ValueError("No readable text found in the PDF. It may be scanned images or corrupted.")

    return all_chunks


def process_csv_document(filename: str, file_bytes: bytes) -> List[DocumentChunk]:
    """Extract rows from CSV file with row numbers and split into structured chunks."""
    # Attempt decoding with multiple common encodings
    decoded_text = ""
    for encoding in ["utf-8-sig", "utf-8", "latin-1", "cp1252"]:
        try:
            decoded_text = file_bytes.decode(encoding)
            break
        except UnicodeDecodeError:
            continue

    if not decoded_text:
        raise ValueError("Could not decode CSV text. Unsupported encoding.")

    lines = [line for line in decoded_text.splitlines() if line.strip()]
    if not lines:
        raise ValueError("The uploaded CSV file is empty.")

    # Detect delimiter
    delimiter = ","
    try:
        sample = "\n".join(lines[:5])
        sniffer = csv.Sniffer()
        dialect = sniffer.sniff(sample)
        delimiter = dialect.delimiter
    except Exception:
        # Fallback to comma or semicolon
        if ";" in lines[0] and "," not in lines[0]:
            delimiter = ";"
        elif "\t" in lines[0] and "," not in lines[0]:
            delimiter = "\t"

    reader = csv.reader(io.StringIO(decoded_text), delimiter=delimiter)
    all_rows = list(reader)
    if not all_rows:
        raise ValueError("No tabular data could be parsed from the CSV file.")

    headers = [h.strip() for h in all_rows[0]]
    data_rows = all_rows[1:]

    # Check if first row is indeed headers or just data
    has_headers = any(not cell.replace('.', '', 1).isdigit() for cell in headers if cell)
    if not has_headers:
        headers = [f"Col_{i+1}" for i in range(len(headers))]
        data_rows = all_rows

    if not data_rows:
        raise ValueError("CSV contains headers but no data rows.")

    all_chunks: List[DocumentChunk] = []

    for idx, row in enumerate(data_rows):
        csv_row_number = idx + 2 if has_headers else idx + 1
        
        # Build key-value representation for the row
        row_parts = []
        for col_idx, cell in enumerate(row):
            val = cell.strip()
            if val:
                col_name = headers[col_idx] if col_idx < len(headers) and headers[col_idx] else f"Column_{col_idx+1}"
                row_parts.append(f"{col_name}: {val}")

        if not row_parts:
            continue

        row_text = f"Row {csv_row_number}: " + " | ".join(row_parts)

        # Split row text into chunks if it exceeds chunk size, or preserve as single chunk
        chunks = split_text_into_chunks(
            text=row_text,
            doc_name=filename,
            doc_type="csv",
            row_number=csv_row_number
        )
        all_chunks.extend(chunks)

    if not all_chunks:
        raise ValueError("No valid data rows found in the CSV file.")

    return all_chunks


def process_document(filename: str, file_bytes: bytes) -> List[DocumentChunk]:
    """Validate and process an uploaded document (PDF or CSV)."""
    sanitized = sanitize_filename(filename)
    lower_name = sanitized.lower()

    if len(file_bytes) > settings.MAX_UPLOAD_SIZE_BYTES:
        raise ValueError(
            f"File size exceeds maximum allowed limit of {settings.MAX_UPLOAD_SIZE_MB}MB."
        )

    if len(file_bytes) == 0:
        raise ValueError("Uploaded file is empty (0 bytes).")

    if lower_name.endswith(".pdf"):
        return process_pdf_document(sanitized, file_bytes)
    elif lower_name.endswith(".csv"):
        return process_csv_document(sanitized, file_bytes)
    else:
        raise ValueError(f"Unsupported file type. Only PDF and CSV documents are allowed.")
