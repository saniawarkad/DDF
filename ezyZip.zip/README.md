# FKNews – AI Fake News Verification System

An academic AI mini-project that verifies news claims strictly and exclusively against uploaded reference documents (PDF and CSV) using Google Gemini and in-memory FAISS vector indexing.

---

## 🌟 Key Architecture & Highlights

- **Frontend Source of Truth Preserved**: Exactly preserves the original HTML layout, modern Tailwind styling, `.glass-panel` glassmorphism, responsive navigation, custom typography (`Newsreader` and `Work Sans`), and Material Symbols icons.
- **Reference-Only Verification**: Strictly enforces a closed-world assumption. Google Gemini is instructed to evaluate claims **solely** on the provided reference context. It never hallucinates external facts. If the documents lack sufficient evidence, it returns **`NOT ENOUGH EVIDENCE`**.
- **Three-Way Verdict Taxonomy**:
  - `TRUE`: Claim is directly confirmed by reference documents.
  - `FALSE` (`FAKE NEWS`): Claim is directly contradicted or refuted by reference documents.
  - `NOT ENOUGH EVIDENCE`: Documents do not contain sufficient evidence to prove or disprove the claim.
- **Precise Citation & Provenance**: Tracks exact PDF page numbers (`Page X`) and CSV row numbers (`Row Y`) along with verbatim supporting quotes and a relevance-weighted context viewer.
- **In-Memory FAISS Vector Store**: Extracts, cleans, and chunks text from uploaded PDFs and CSVs, generates embeddings, and indexes them into an in-memory FAISS `IndexFlatIP` index using cosine similarity.
- **Ephemeral Session Privacy (RAM Only)**:
  - No persistent database, no disk storage, and no localStorage/IndexedDB.
  - Documents, vector indices, and verification histories exist purely in server RAM for the active browser session.
  - Refreshing or reopening the browser starts completely clean.
  - Expired sessions are automatically cleared by a background TTL task.
- **Configurable & Secure Backend**:
  - Configurable Gemini model (`GEMINI_MODEL`, default: `gemini-2.5-flash`).
  - Google Gemini API key kept securely on the backend in `.env`.
  - Comprehensive input sanitization, file-type checking (`.pdf`, `.csv`), and size limits (15 MB).

---

## 📁 Project Structure

```
fknews/
├── app/
│   ├── __init__.py
│   ├── config.py              # Configuration & settings (.env loader, model, limits, TTL)
│   ├── document_processing.py  # PDF text extraction with page numbers & CSV with row numbers
│   ├── embeddings.py          # Gemini text-embedding-004 + local multi-gram vectorizer
│   ├── vector_store.py        # In-memory FAISS cosine similarity vector store
│   ├── gemini_client.py       # Google Gemini API client with strict prompt constraints
│   ├── session_manager.py     # Ephemeral in-memory session manager with TTL cleanup
│   ├── main.py                # FastAPI app, static mounting, CORS, and lifecycle tasks
│   └── api/
│       ├── __init__.py
│       ├── routes.py          # REST endpoints (/upload, /verify, /history, /clear, etc.)
│       └── schemas.py         # Pydantic request and response schemas
├── static/
│   ├── index.html             # The preserved frontend UI source of truth
│   └── js/
│       └── app.js             # Frontend controller connecting all UI controls to backend
├── sample_data/
│   ├── climate_report_2025.pdf# Sample multi-page PDF reference document
│   └── ev_lifecycle_emissions.csv # Sample CSV reference dataset
├── tests/
│   ├── test_document_processing.py # Unit tests for PDF/CSV extraction & validation
│   ├── test_vector_store.py   # Unit tests for FAISS vector indexing & search
│   ├── test_api.py            # Integration tests for FastAPI endpoints & session isolation
│   └── test_full_workflow.py  # End-to-end user journey workflow test
├── .env.example               # Environment variables template
├── .env                       # Local environment configuration (contains GEMINI_API_KEY)
├── requirements.txt           # Python dependency manifest
├── run.py                     # Server launcher script
└── README.md                  # Project documentation
```

---

## 🚀 Getting Started

### 1. Prerequisites
- Python 3.10+ installed
- A Google Gemini API key from [Google AI Studio](https://aistudio.google.com/)

### 2. Configure Environment Variables
Copy `.env.example` to `.env` (if not already done) and add your Gemini API key:
```bash
GEMINI_API_KEY=your_actual_gemini_api_key_here
GEMINI_MODEL=gemini-2.5-flash
HOST=127.0.0.1
PORT=8000
```

> **Security Note:** Never commit your actual API key to GitHub or version control.

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Application
```bash
python run.py
```
Or with uvicorn directly:
```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Open your browser and navigate to:
```
http://127.0.0.1:8000
```

---

## 🧪 Running the Test Suite

Run the full automated test suite (including document processing, FAISS retrieval, and end-to-end workflow verification):
```bash
python -m unittest discover tests
```

---

## 🔌 API Endpoints Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Health check & Gemini configuration status |
| `POST` | `/api/session/init` | Initialize or retrieve ephemeral session |
| `POST` | `/api/session/clear` | Wipe current session from server RAM |
| `POST` | `/api/documents/upload` | Upload & index PDF/CSV reference documents |
| `GET` | `/api/documents` | List active documents in session memory |
| `DELETE` | `/api/documents/{doc_name}` | Remove a document from session vector index |
| `POST` | `/api/verify` | Verify a claim against session documents via Gemini |
| `GET` | `/api/history` | Retrieve temporary verification history for session |
| `GET` | `/api/stats` | Retrieve real-time session statistics |
