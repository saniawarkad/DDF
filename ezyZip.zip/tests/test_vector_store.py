import unittest
from app.document_processing import DocumentChunk
from app.vector_store import FAISSVectorStore

class TestFAISSVectorStore(unittest.TestCase):
    def setUp(self):
        self.store = FAISSVectorStore()

    def test_indexing_and_search(self):
        chunks = [
            DocumentChunk(
                doc_name="climate_2025.pdf",
                doc_type="pdf",
                text="Electric vehicles produce substantially lower lifetime carbon emissions compared to internal combustion engines.",
                page_number=14
            ),
            DocumentChunk(
                doc_name="nutrition_guide.csv",
                doc_type="csv",
                text="Vitamin C intake supports immune health but does not cure viral influenza.",
                row_number=5
            ),
            DocumentChunk(
                doc_name="space_mission.pdf",
                doc_type="pdf",
                text="The Artemis lunar mission aims to land astronauts at the Moon's South Pole by 2026.",
                page_number=3
            )
        ]

        indexed_count = self.store.add_chunks(chunks)
        self.assertEqual(indexed_count, 3)
        self.assertEqual(self.store.total_chunks, 3)

        # Search for EV emissions
        results = self.store.search("Do electric vehicles cause lower emissions than petrol cars?", top_k=1)
        self.assertEqual(len(results), 1)
        top_match = results[0]
        self.assertEqual(top_match["doc_name"], "climate_2025.pdf")
        self.assertEqual(top_match["page_number"], 14)
        self.assertGreater(top_match["similarity_score"], 0.1)

        # Search for Artemis Moon mission
        moon_results = self.store.search("Artemis moon landing lunar south pole", top_k=1)
        self.assertEqual(len(moon_results), 1)
        self.assertEqual(moon_results[0]["doc_name"], "space_mission.pdf")

    def test_remove_document(self):
        chunks = [
            DocumentChunk("doc1.pdf", "pdf", "Sample text one", page_number=1),
            DocumentChunk("doc2.pdf", "pdf", "Sample text two", page_number=2),
        ]
        self.store.add_chunks(chunks)
        self.assertEqual(self.store.total_chunks, 2)

        self.store.remove_document("doc1.pdf")
        self.assertEqual(self.store.total_chunks, 1)
        self.assertEqual(self.store.chunks[0].doc_name, "doc2.pdf")

    def test_clear_store(self):
        chunks = [DocumentChunk("doc.pdf", "pdf", "Sample text", page_number=1)]
        self.store.add_chunks(chunks)
        self.store.clear()
        self.assertEqual(self.store.total_chunks, 0)
        self.assertEqual(len(self.store.search("Sample", top_k=2)), 0)

if __name__ == "__main__":
    unittest.main()
