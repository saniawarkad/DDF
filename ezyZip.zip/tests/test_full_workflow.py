import io
import unittest
from unittest.mock import patch, AsyncMock
from fastapi.testclient import TestClient
from app.main import app
from app.session_manager import session_manager

class TestFullFKNewsWorkflow(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.session_a = "user_browser_tab_a"

    def test_complete_flow(self):
        # 1. Start clean session A
        init_resp = self.client.post("/api/session/init", headers={"X-Session-ID": self.session_a})
        self.assertEqual(init_resp.status_code, 200)
        self.assertEqual(init_resp.json()["stats"]["documents_uploaded"], 0)

        # 2. Prepare multi-page PDF document
        pdf_bytes = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R 4 0 R] /Count 2 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /Resources << /Font << /F1 5 0 R >> >> /MediaBox [0 0 612 792] /Contents 6 0 R >> endobj
4 0 obj << /Type /Page /Parent 2 0 R /Resources << /Font << /F1 5 0 R >> >> /MediaBox [0 0 612 792] /Contents 7 0 R >> endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
6 0 obj << /Length 64 >> stream
BT /F1 12 Tf 50 700 Td (Climate Report 2025: Global temperatures rose 1.2 degrees.) Tj ET
endstream endobj
7 0 obj << /Length 135 >> stream
BT /F1 12 Tf 50 700 Td (Comprehensive lifecycle analyses consistently demonstrate that battery electric vehicles result in a 50 to 70 percent reduction in total emissions.) Tj ET
endstream endobj
xref
0 8
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000227 00000 n 
0000000339 00000 n 
0000000406 00000 n 
0000000520 00000 n 
trailer << /Size 8 /Root 1 0 R >>
startxref
706
%%EOF"""

        # Prepare CSV reference document
        csv_bytes = (
            "Year,Sector,Observation\n"
            "2024,Energy,Global solar additions reached record highs.\n"
            "2025,Transport,Battery recycling efficiency exceeded 95 percent across testing facilities.\n"
        ).encode("utf-8")

        # Upload both PDF and CSV
        files = [
            ("files", ("climate_report_2025.pdf", io.BytesIO(pdf_bytes), "application/pdf")),
            ("files", ("energy_stats_2025.csv", io.BytesIO(csv_bytes), "text/csv"))
        ]

        upload_resp = self.client.post(
            "/api/documents/upload",
            files=files,
            headers={"X-Session-ID": self.session_a}
        )
        self.assertEqual(upload_resp.status_code, 200)
        upload_data = upload_resp.json()
        self.assertTrue(upload_data["success"])
        self.assertEqual(len(upload_data["documents"]), 2)
        self.assertGreater(upload_data["total_chunks"], 0)

        # 3. Verify Claim 1: Electric vehicles pollution claim (Contradicted by Page 2 of PDF)
        claim_1 = "Electric vehicles emit more pollution than petrol vehicles"
        
        # Test vector search retrieval first
        session_obj = session_manager.get_session(self.session_a)
        retrieved_1 = session_obj.vector_store.search(claim_1, top_k=2)
        self.assertGreater(len(retrieved_1), 0)
        # Ensure Page 2 of PDF was retrieved
        self.assertTrue(any(c["doc_name"] == "climate_report_2025.pdf" and c["page_number"] == 2 for c in retrieved_1))

        # Mock Gemini verification returning FALSE with exact page reference
        with patch("app.api.routes.verify_claim_with_gemini", new_callable=AsyncMock) as mock_gemini:
            mock_gemini.return_value = {
                "verdict": "FALSE",
                "confidence": 95,
                "explanation": "The claim is directly refuted by the climate report which confirms a 50-70% reduction in total emissions.",
                "supporting_evidence": "battery electric vehicles result in a 50 to 70 percent reduction in total emissions",
                "source_document": "climate_report_2025.pdf",
                "page_number": 2,
                "row_number": None,
                "error": False
            }

            resp_1 = self.client.post(
                "/api/verify",
                json={"claim": claim_1},
                headers={"X-Session-ID": self.session_a}
            )
            self.assertEqual(resp_1.status_code, 200)
            res_json_1 = resp_1.json()
            self.assertEqual(res_json_1["verdict"], "FALSE")
            self.assertEqual(res_json_1["confidence"], 95)
            self.assertEqual(res_json_1["source_document"], "climate_report_2025.pdf")
            self.assertEqual(res_json_1["page_number"], 2)

        # 4. Verify Claim 2: Solar energy claim (Supported by CSV Row 2)
        claim_2 = "Solar additions reached record highs in 2024"
        with patch("app.api.routes.verify_claim_with_gemini", new_callable=AsyncMock) as mock_gemini:
            mock_gemini.return_value = {
                "verdict": "TRUE",
                "confidence": 98,
                "explanation": "The claim is directly confirmed by row 2 of energy_stats_2025.csv.",
                "supporting_evidence": "Global solar additions reached record highs.",
                "source_document": "energy_stats_2025.csv",
                "page_number": None,
                "row_number": 2,
                "error": False
            }

            resp_2 = self.client.post(
                "/api/verify",
                json={"claim": claim_2},
                headers={"X-Session-ID": self.session_a}
            )
            self.assertEqual(resp_2.status_code, 200)
            res_json_2 = resp_2.json()
            self.assertEqual(res_json_2["verdict"], "TRUE")
            self.assertEqual(res_json_2["confidence"], 98)
            self.assertEqual(res_json_2["row_number"], 2)

        # 5. Verify Claim 3: Mars colonization (Not mentioned in reference docs)
        claim_3 = "Humans have established colonies on Mars"
        with patch("app.api.routes.verify_claim_with_gemini", new_callable=AsyncMock) as mock_gemini:
            mock_gemini.return_value = {
                "verdict": "NOT ENOUGH EVIDENCE",
                "confidence": 0,
                "explanation": "No reference documents contain any information regarding Mars colonization.",
                "supporting_evidence": "No reference data found.",
                "source_document": None,
                "page_number": None,
                "row_number": None,
                "error": False
            }

            resp_3 = self.client.post(
                "/api/verify",
                json={"claim": claim_3},
                headers={"X-Session-ID": self.session_a}
            )
            self.assertEqual(resp_3.status_code, 200)
            self.assertEqual(resp_3.json()["verdict"], "NOT ENOUGH EVIDENCE")

        # 6. Check History for Session A: must contain all 3 claims
        hist_resp = self.client.get("/api/history", headers={"X-Session-ID": self.session_a})
        self.assertEqual(hist_resp.status_code, 200)
        history = hist_resp.json()["history"]
        self.assertEqual(len(history), 3)
        self.assertEqual(history[0]["verdict"], "FALSE")
        self.assertEqual(history[1]["verdict"], "TRUE")
        self.assertEqual(history[2]["verdict"], "NOT ENOUGH EVIDENCE")

        # 7. Check Stats for Session A
        stats_resp = self.client.get("/api/stats", headers={"X-Session-ID": self.session_a})
        self.assertEqual(stats_resp.status_code, 200)
        stats = stats_resp.json()
        self.assertEqual(stats["documents_uploaded"], 2)
        self.assertEqual(stats["claims_verified"], 3)
        self.assertEqual(stats["fake_claims_detected"], 1)

        # 8. Simulate Browser Refresh / New Window (Session B starts)
        session_b = "user_browser_tab_b_after_refresh"
        b_init = self.client.post("/api/session/init", headers={"X-Session-ID": session_b})
        self.assertEqual(b_init.status_code, 200)
        
        # Confirm Session B starts clean with zero previous documents or history
        b_docs = self.client.get("/api/documents", headers={"X-Session-ID": session_b}).json()
        self.assertEqual(len(b_docs["documents"]), 0)
        self.assertEqual(b_docs["total_chunks"], 0)

        b_hist = self.client.get("/api/history", headers={"X-Session-ID": session_b}).json()
        self.assertEqual(len(b_hist["history"]), 0)

        b_stats = self.client.get("/api/stats", headers={"X-Session-ID": session_b}).json()
        self.assertEqual(b_stats["documents_uploaded"], 0)
        self.assertEqual(b_stats["claims_verified"], 0)

if __name__ == "__main__":
    unittest.main()
