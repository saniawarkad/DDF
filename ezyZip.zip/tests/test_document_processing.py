import io
import unittest
from pypdf import PdfWriter
from app.document_processing import (
    process_document,
    process_pdf_document,
    process_csv_document,
    sanitize_filename
)

class TestDocumentProcessing(unittest.TestCase):
    def test_sanitize_filename(self):
        self.assertEqual(sanitize_filename("../../etc/passwd.pdf"), "passwd.pdf")
        self.assertEqual(sanitize_filename("valid_report-2025.csv"), "valid_report-2025.csv")
        self.assertTrue(sanitize_filename(".hidden.pdf").endswith(".pdf"))

    def test_csv_processing(self):
        csv_content = (
            "Claim_ID,Topic,Statement,Source,Verdict\n"
            "101,Environment,Electric vehicles emit 60% less lifetime emissions,EPA Study,Supported\n"
            "102,Health,Drinking green tea cures all bacterial infections,Health Blog,Refuted\n"
        ).encode("utf-8")

        chunks = process_csv_document("news_dataset.csv", csv_content)
        self.assertGreaterEqual(len(chunks), 2)
        
        # Verify row numbers
        row_numbers = [c.row_number for c in chunks]
        self.assertIn(2, row_numbers)
        self.assertIn(3, row_numbers)
        
        # Verify citation
        self.assertTrue(any("Row 2" in c.get_citation() for c in chunks))
        self.assertTrue(any("Electric vehicles" in c.text for c in chunks))

    def test_pdf_processing(self):
        # Create a synthetic PDF with 2 pages in memory
        writer = PdfWriter()
        writer.add_blank_page(width=200, height=200)
        writer.add_blank_page(width=200, height=200)
        
        # Note: blank PDF pages have no text, so should raise ValueError about no readable text
        pdf_bytes = io.BytesIO()
        writer.write(pdf_bytes)
        
        with self.assertRaises(ValueError):
            process_pdf_document("empty.pdf", pdf_bytes.getvalue())

    def test_multipage_pdf_with_text(self):
        pdf_sample = b"""%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R 4 0 R] /Count 2 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /Resources << /Font << /F1 5 0 R >> >> /MediaBox [0 0 612 792] /Contents 6 0 R >> endobj
4 0 obj << /Type /Page /Parent 2 0 R /Resources << /Font << /F1 5 0 R >> >> /MediaBox [0 0 612 792] /Contents 7 0 R >> endobj
5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj
6 0 obj << /Length 64 >> stream
BT /F1 12 Tf 50 700 Td (Climate Report 2025: Global temperatures rose 1.2 degrees.) Tj ET
endstream endobj
7 0 obj << /Length 72 >> stream
BT /F1 12 Tf 50 700 Td (Electric vehicles lifetime emissions are 50 to 70 percent lower.) Tj ET
endstream endobj
xref
0 8
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000227 00000 n 
0000000339 00000 n 
0000000406 00000 n 
0000000520 00000 n 
trailer << /Size 8 /Root 1 0 R >>
startxref
643
%%EOF"""
        chunks = process_pdf_document("sample_climate_report.pdf", pdf_sample)
        self.assertEqual(len(chunks), 2)
        self.assertEqual(chunks[0].page_number, 1)
        self.assertEqual(chunks[0].get_citation(), "sample_climate_report.pdf (Page 1)")
        self.assertIn("Climate Report 2025", chunks[0].text)

        self.assertEqual(chunks[1].page_number, 2)
        self.assertEqual(chunks[1].get_citation(), "sample_climate_report.pdf (Page 2)")
        self.assertIn("Electric vehicles", chunks[1].text)

    def test_invalid_formats(self):
        with self.assertRaises(ValueError):
            process_document("malicious.exe", b"binary content")

        with self.assertRaises(ValueError):
            process_document("empty.csv", b"")

if __name__ == "__main__":
    unittest.main()
