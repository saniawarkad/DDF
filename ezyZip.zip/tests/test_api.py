import io
import unittest
from unittest.mock import patch, AsyncMock
from fastapi.testclient import TestClient
from app.main import app

class TestFKNewsAPI(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.session_id = "test_sess_001"

    def test_health_check(self):
        resp = self.client.get("/api/health")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["status"], "healthy")
        self.assertIn("gemini_model", data)
        self.assertIn("gemini_api_key_configured", data)

    def test_session_init(self):
        resp = self.client.post("/api/session/init", headers={"X-Session-ID": self.session_id})
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["session_id"], self.session_id)
        self.assertEqual(data["stats"]["documents_uploaded"], 0)

    def test_upload_and_verification_flow(self):
        # 1. Prepare sample CSV reference document
        csv_data = (
            "ID,Topic,Evidence_Statement,Source\n"
            "1,Climate,Solar energy generation worldwide exceeded 1500 terawatt hours in 2024,Global Energy Report\n"
            "2,Automotive,Electric vehicles reduce lifetime carbon emissions by 60% compared to petrol vehicles,Automotive Life Cycle Analysis\n"
        ).encode("utf-8")

        # 2. Upload to session
        files = [
            ("files", ("climate_study.csv", io.BytesIO(csv_data), "text/csv"))
        ]
        upload_resp = self.client.post(
            "/api/documents/upload",
            files=files,
            headers={"X-Session-ID": self.session_id}
        )
        self.assertEqual(upload_resp.status_code, 200)
        upload_json = upload_resp.json()
        self.assertTrue(upload_json["success"])
        self.assertGreater(upload_json["total_chunks"], 0)

        # 3. Check stats updated
        stats_resp = self.client.get("/api/stats", headers={"X-Session-ID": self.session_id})
        self.assertEqual(stats_resp.status_code, 200)
        self.assertEqual(stats_resp.json()["documents_uploaded"], 1)

        # 4. Verify claim against document using mocked Gemini response
        mock_gemini_response = {
            "verdict": "FALSE",
            "confidence": 92,
            "explanation": "The claim is contradicted by the reference document which explicitly states electric vehicles reduce lifetime emissions by 60%.",
            "supporting_evidence": "Electric vehicles reduce lifetime carbon emissions by 60% compared to petrol vehicles",
            "source_document": "climate_study.csv",
            "page_number": None,
            "row_number": 3,
            "error": False
        }

        with patch("app.api.routes.verify_claim_with_gemini", new_callable=AsyncMock) as mock_gemini:
            mock_gemini.return_value = mock_gemini_response

            claim_payload = {
                "claim": "Electric vehicles emit more lifetime pollution than petrol vehicles."
            }
            verify_resp = self.client.post(
                "/api/verify",
                json=claim_payload,
                headers={"X-Session-ID": self.session_id}
            )

            self.assertEqual(verify_resp.status_code, 200)
            verify_json = verify_resp.json()
            self.assertEqual(verify_json["verdict"], "FALSE")
            self.assertEqual(verify_json["confidence"], 92)
            self.assertIn("climate_study.csv", verify_json["source_document"])
            self.assertEqual(verify_json["row_number"], 3)
            self.assertGreater(len(verify_json["retrieved_chunks"]), 0)

        # 5. Verify claim recorded in temporary session history
        history_resp = self.client.get("/api/history", headers={"X-Session-ID": self.session_id})
        self.assertEqual(history_resp.status_code, 200)
        history = history_resp.json()["history"]
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["verdict"], "FALSE")

        # 6. Verify second claim with different session (Isolation Test)
        other_session_id = "test_sess_002"
        other_history = self.client.get("/api/history", headers={"X-Session-ID": other_session_id}).json()["history"]
        self.assertEqual(len(other_history), 0, "Other session must start completely empty and isolated.")

        # 7. Clear Session (Refresh/Restart behavior)
        clear_resp = self.client.post("/api/session/clear", headers={"X-Session-ID": self.session_id})
        self.assertEqual(clear_resp.status_code, 200)

        # Verify all data was completely wiped from memory
        cleared_docs = self.client.get("/api/documents", headers={"X-Session-ID": self.session_id}).json()
        self.assertEqual(len(cleared_docs["documents"]), 0)
        self.assertEqual(cleared_docs["total_chunks"], 0)

        cleared_history = self.client.get("/api/history", headers={"X-Session-ID": self.session_id}).json()
        self.assertEqual(len(cleared_history["history"]), 0)

    def test_verify_without_documents(self):
        empty_session = "empty_session_123"
        resp = self.client.post(
            "/api/verify",
            json={"claim": "Some arbitrary claim without reference files."},
            headers={"X-Session-ID": empty_session}
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["verdict"], "NOT ENOUGH EVIDENCE")
        self.assertEqual(data["confidence"], 0)
        self.assertIn("No reference documents", data["explanation"])

if __name__ == "__main__":
    unittest.main()
